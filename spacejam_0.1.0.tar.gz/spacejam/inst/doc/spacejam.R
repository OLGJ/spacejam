## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(spacejam)

## -----------------------------------------------------------------------------
# You can call the CME function as following:
a <- spacejam("2010-01-01", "2010-12-31")
# This will return a class object which provides data about CME's from 2010. The dates can be changed as you prefer.

## -----------------------------------------------------------------------------
# Using `a` above, we can explore the different tools that comes with the package.
# For example to check what data was retrieved:
a$data


# Info about the response:
a$response

