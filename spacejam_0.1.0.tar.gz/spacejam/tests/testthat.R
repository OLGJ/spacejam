library(testthat)
library(spacejam)

test_check("spacejam")
